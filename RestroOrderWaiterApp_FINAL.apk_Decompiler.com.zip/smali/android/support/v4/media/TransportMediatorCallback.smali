###### Class android.support.v4.media.TransportMediatorCallback (android.support.v4.media.TransportMediatorCallback)
.class interface abstract Landroid/support/v4/media/TransportMediatorCallback;
.super Ljava/lang/Object;
.source "TransportMediatorCallback.java"


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x12
.end annotation

.annotation build Landroid/support/annotation/RequiresApi;
    value = 0x12
.end annotation


# virtual methods
.method public abstract getPlaybackPosition()J
.end method

.method public abstract handleAudioFocusChange(I)V
.end method

.method public abstract handleKey(Landroid/view/KeyEvent;)V
.end method

.method public abstract playbackPositionUpdate(J)V
.end method
