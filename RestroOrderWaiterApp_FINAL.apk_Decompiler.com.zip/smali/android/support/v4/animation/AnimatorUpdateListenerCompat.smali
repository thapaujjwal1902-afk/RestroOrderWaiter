###### Class android.support.v4.animation.AnimatorUpdateListenerCompat (android.support.v4.animation.AnimatorUpdateListenerCompat)
.class public interface abstract Landroid/support/v4/animation/AnimatorUpdateListenerCompat;
.super Ljava/lang/Object;
.source "AnimatorUpdateListenerCompat.java"


# annotations
.annotation build Landroid/support/annotation/RestrictTo;
    value = {
        .enum Landroid/support/annotation/RestrictTo$Scope;->LIBRARY_GROUP:Landroid/support/annotation/RestrictTo$Scope;
    }
.end annotation


# virtual methods
.method public abstract onAnimationUpdate(Landroid/support/v4/animation/ValueAnimatorCompat;)V
.end method
