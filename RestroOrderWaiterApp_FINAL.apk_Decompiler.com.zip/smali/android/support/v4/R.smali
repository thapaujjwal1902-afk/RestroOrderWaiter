###### Class android.support.v4.R (android.support.v4.R)
.class public final Landroid/support/v4/R;
.super Ljava/lang/Object;
.source "R.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
