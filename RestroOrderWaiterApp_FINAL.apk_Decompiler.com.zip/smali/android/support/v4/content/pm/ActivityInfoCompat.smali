###### Class android.support.v4.content.pm.ActivityInfoCompat (android.support.v4.content.pm.ActivityInfoCompat)
.class public final Landroid/support/v4/content/pm/ActivityInfoCompat;
.super Ljava/lang/Object;
.source "ActivityInfoCompat.java"


# static fields
.field public static final CONFIG_UI_MODE:I = 0x200


# direct methods
.method private constructor <init>()V
    .registers 1

    .prologue
    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    return-void
.end method
