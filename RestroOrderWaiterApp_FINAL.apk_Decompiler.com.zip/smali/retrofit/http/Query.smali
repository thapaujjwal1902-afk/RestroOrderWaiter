###### Class retrofit.http.Query (retrofit.http.Query)
.class public interface abstract annotation Lretrofit/http/Query;
.super Ljava/lang/Object;
.source "Query.java"

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation system Ldalvik/annotation/AnnotationDefault;
    value = .subannotation Lretrofit/http/Query;
        encodeName = false
        encodeValue = true
    .end subannotation
.end annotation

.annotation runtime Ljava/lang/annotation/Documented;
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->RUNTIME:Ljava/lang/annotation/RetentionPolicy;
.end annotation

.annotation runtime Ljava/lang/annotation/Target;
    value = {
        .enum Ljava/lang/annotation/ElementType;->PARAMETER:Ljava/lang/annotation/ElementType;
    }
.end annotation


# virtual methods
.method public abstract encodeName()Z
.end method

.method public abstract encodeValue()Z
.end method

.method public abstract value()Ljava/lang/String;
.end method
