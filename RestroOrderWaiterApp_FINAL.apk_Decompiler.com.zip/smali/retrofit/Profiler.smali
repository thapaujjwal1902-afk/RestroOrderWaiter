###### Class retrofit.Profiler (retrofit.Profiler)
.class public interface abstract Lretrofit/Profiler;
.super Ljava/lang/Object;
.source "Profiler.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lretrofit/Profiler$RequestInformation;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract afterCall(Lretrofit/Profiler$RequestInformation;JILjava/lang/Object;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lretrofit/Profiler$RequestInformation;",
            "JITT;)V"
        }
    .end annotation
.end method

.method public abstract beforeCall()Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation
.end method

###### Class retrofit.Profiler.RequestInformation (retrofit.Profiler$RequestInformation)
.class public final Lretrofit/Profiler$RequestInformation;
.super Ljava/lang/Object;
.source "Profiler.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lretrofit/Profiler;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "RequestInformation"
.end annotation


# instance fields
.field private final baseUrl:Ljava/lang/String;

.field private final contentLength:J

.field private final contentType:Ljava/lang/String;

.field private final method:Ljava/lang/String;

.field private final relativePath:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .registers 7
    .param p1, "method"    # Ljava/lang/String;
    .param p2, "baseUrl"    # Ljava/lang/String;
    .param p3, "relativePath"    # Ljava/lang/String;
    .param p4, "contentLength"    # J
    .param p6, "contentType"    # Ljava/lang/String;

    .prologue
    .line 55
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 56
    iput-object p1, p0, Lretrofit/Profiler$RequestInformation;->method:Ljava/lang/String;

    .line 57
    iput-object p2, p0, Lretrofit/Profiler$RequestInformation;->baseUrl:Ljava/lang/String;

    .line 58
    iput-object p3, p0, Lretrofit/Profiler$RequestInformation;->relativePath:Ljava/lang/String;

    .line 59
    iput-wide p4, p0, Lretrofit/Profiler$RequestInformation;->contentLength:J

    .line 60
    iput-object p6, p0, Lretrofit/Profiler$RequestInformation;->contentType:Ljava/lang/String;

    .line 61
    return-void
.end method


# virtual methods
.method public getBaseUrl()Ljava/lang/String;
    .registers 2

    .prologue
    .line 70
    iget-object v0, p0, Lretrofit/Profiler$RequestInformation;->baseUrl:Ljava/lang/String;

    return-object v0
.end method

.method public getContentLength()J
    .registers 3

    .prologue
    .line 80
    iget-wide v0, p0, Lretrofit/Profiler$RequestInformation;->contentLength:J

    return-wide v0
.end method

.method public getContentType()Ljava/lang/String;
    .registers 2

    .prologue
    .line 85
    iget-object v0, p0, Lretrofit/Profiler$RequestInformation;->contentType:Ljava/lang/String;

    return-object v0
.end method

.method public getMethod()Ljava/lang/String;
    .registers 2

    .prologue
    .line 65
    iget-object v0, p0, Lretrofit/Profiler$RequestInformation;->method:Ljava/lang/String;

    return-object v0
.end method

.method public getRelativePath()Ljava/lang/String;
    .registers 2

    .prologue
    .line 75
    iget-object v0, p0, Lretrofit/Profiler$RequestInformation;->relativePath:Ljava/lang/String;

    return-object v0
.end method
