###### Class org.greenrobot.eventbus.meta.SubscriberInfoIndex (org.greenrobot.eventbus.meta.SubscriberInfoIndex)
.class public interface abstract Lorg/greenrobot/eventbus/meta/SubscriberInfoIndex;
.super Ljava/lang/Object;
.source "SubscriberInfoIndex.java"


# virtual methods
.method public abstract getSubscriberInfo(Ljava/lang/Class;)Lorg/greenrobot/eventbus/meta/SubscriberInfo;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class",
            "<*>;)",
            "Lorg/greenrobot/eventbus/meta/SubscriberInfo;"
        }
    .end annotation
.end method
