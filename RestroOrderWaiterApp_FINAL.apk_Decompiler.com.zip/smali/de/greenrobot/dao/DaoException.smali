###### Class de.greenrobot.dao.DaoException (de.greenrobot.dao.DaoException)
.class public Lde/greenrobot/dao/DaoException;
.super Landroid/database/SQLException;
.source "DaoException.java"


# static fields
.field private static final serialVersionUID:J = -0x5192a0db69eecaf3L


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 30
    invoke-direct {p0}, Landroid/database/SQLException;-><init>()V

    .line 31
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 2
    .param p1, "error"    # Ljava/lang/String;

    .prologue
    .line 34
    invoke-direct {p0, p1}, Landroid/database/SQLException;-><init>(Ljava/lang/String;)V

    .line 35
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .registers 3
    .param p1, "error"    # Ljava/lang/String;
    .param p2, "cause"    # Ljava/lang/Throwable;

    .prologue
    .line 38
    invoke-direct {p0, p1}, Landroid/database/SQLException;-><init>(Ljava/lang/String;)V

    .line 39
    invoke-virtual {p0, p2}, Lde/greenrobot/dao/DaoException;->safeInitCause(Ljava/lang/Throwable;)V

    .line 40
    return-void
.end method

.method public constructor <init>(Ljava/lang/Throwable;)V
    .registers 2
    .param p1, "th"    # Ljava/lang/Throwable;

    .prologue
    .line 42
    invoke-direct {p0}, Landroid/database/SQLException;-><init>()V

    .line 43
    invoke-virtual {p0, p1}, Lde/greenrobot/dao/DaoException;->safeInitCause(Ljava/lang/Throwable;)V

    .line 44
    return-void
.end method


# virtual methods
.method protected safeInitCause(Ljava/lang/Throwable;)V
    .registers 4
    .param p1, "cause"    # Ljava/lang/Throwable;

    .prologue
    .line 48
    :try_start_0
    invoke-virtual {p0, p1}, Lde/greenrobot/dao/DaoException;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    :try_end_3
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_3} :catch_4

    .line 53
    :goto_3
    return-void

    .line 49
    :catch_4
    move-exception v0

    .line 50
    .local v0, "e":Ljava/lang/Throwable;
    const-string v1, "Could not set initial cause"

    invoke-static {v1, v0}, Lde/greenrobot/dao/DaoLog;->e(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 51
    const-string v1, "Initial cause is:"

    invoke-static {v1, p1}, Lde/greenrobot/dao/DaoLog;->e(Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_3
.end method
